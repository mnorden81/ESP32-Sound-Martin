# ESP32-RC-Sound v2.22

**Autor:** PiperPilot

ESP32-basiertes RC-Soundmodul mit I2S-Audioausgabe, SD-Karten-Wiedergabe, WLAN-Weboberfläche, CRSF-Parametersystem und optionaler LiPo-Telemetrie über S.Port (Hardware V4).

---

## Neu in v2.22 (gegenüber v2.21) — Bugfix Web-UI

**Fehlerbild:** Nach dem Speichern eines Sound- oder Motor-Modus in der
Web-Oberfläche zeigte die Auswahlbox beim nächsten Tab-Wechsel wieder
den alten Wert (z.B. wieder "Normal" statt "Loop"/"Tippbetrieb"),
obwohl der neue Wert korrekt im NVS-Speicher des ESP32 gespeichert war
(nach einem Browser-Neuladen (F5) war der Wert immer schon korrekt).

**Ursache:** Das lokale `cfg`-Objekt im Browser-JavaScript wird nur
beim initialen Laden der Seite befüllt (`loadConfig()`). `saveSound()`
und `saveMotor()` schrieben den neuen Wert zwar korrekt per
`/api/sound` an den ESP32, aktualisierten aber nicht das lokale
`cfg`-Objekt — beim nächsten Tab-/Sound-Wechsel rendert `selSnd()`
dann wieder aus dem veralteten `cfg`.

**Fix:** `saveSound()` und `saveMotor()` aktualisieren `cfg` jetzt
nach erfolgreichem Speichern direkt mit den neuen Werten (siehe
`WebServerManager.cpp`).

---

## Neu in v2.21 (gegenüber v2.2) — Bugfix

**Fehlerbild:** Der Motorsound (und andere gerade laufende Sounds) konnten
abrupt abbrechen, wenn ein Sound im **Tipp-Modus** (Mode_Sound==2)
ausgeschaltet wurde, nachdem er selbst schon fertig durchgespielt hatte.

**Ursache:** `handleSound()` ruft beim Loslassen eines Tipp-Sounds
unconditional `I2SAudio.Stop(snd)` auf, auch wenn dieser Sound sich
zuvor schon selbst (nach dem natürlichen Ende) aus der internen
Playliste entfernt hatte. `RemoveFromPlayList()` in `XT_I2S_Audio.cpp`
interpretierte einen Sound mit `PreviousItem == nullptr` und
`NextItem == nullptr` fälschlich als "einziger Eintrag in der Liste"
und setzte dadurch bedingungslos `FirstPlayListItem` und
`LastPlayListItem` auf `nullptr` — das kappte die komplette aktive
Playliste, unabhängig davon, was tatsächlich gerade lief (Motorsound,
andere Loop-Sounds, etc.).

**Fix:** `XT_I2S_Class::Stop()` prüft jetzt vorab mit `AlreadyPlaying()`,
ob der Sound überhaupt noch in der Playliste verlinkt ist, bevor
`RemoveFromPlayList()` aufgerufen wird (siehe `XT_I2S_Audio.cpp`).

---

## Neu in v2.2 (gegenüber v2.0)

Übernommene Learnings aus dem parallel entwickelten Projekt
**ESP32-GPS-Telemetry**: dort wurden beim Aufbau/Debuggen eines eigenen
S.Port/CRSF-Sensors mehrere granulare Diagnosezähler entwickelt, die sich
als sehr hilfreich erwiesen haben, um „geht nicht" in eine konkrete
Ursache aufzulösen. Diese sind jetzt auch im Debug-Tab dieses Moduls
verfügbar:

- **Neue Debug-Karte „S.Port Diagnose"**: Rohbytes empfangen, gesendete
  Polls, gültige Frames, „keine/ungültige Antwort"-Zähler, CRC-Fehler,
  zuletzt gesehene Poll-ID – inkl. Klartext-Hinweisen (z. B. „es kommen
  gar keine Bytes an → Verkabelung/Diode/Baudrate prüfen" oder „Polls
  werden gesendet, aber nie eine gültige Antwort → passt die Physical ID
  zu den angeschlossenen Sensoren?")
- **Neue Debug-Karte „CRSF Diagnose"**: Rohbytes, gültige Frames,
  CRC-Fehler, empfangene Device-Pings, Parameter-Reads/-Writes – inkl.
  Hinweis, falls Bytes ankommen, aber noch nie ein Device-Ping (dann hilft
  „Sensoren entdecken" am Sender auszulösen)
- Diese Zähler laufen **immer mit**, nicht nur wenn `SPORT_DEBUG_RAW`
  aktiviert ist – vorher war die einzige Diagnose online/offline pro
  Sensor bzw. das serielle Debug-Log

**Zusätzlich gefunden und abgesichert:** GPIO27 wird bei Hardware V5
sowohl vom GPS-Modul (RX) als auch von SBUS (TX-Pin der SBUS-UART,
`sbus_rx(&Serial1, 16, 27, true)`) beansprucht – `Hardware_Config` (V1–V5)
und `Einkanal_RC_System` (SBUS/CRSF) waren bisher unabhängig voneinander
einstellbar, sodass sich V5 + SBUS unbemerkt in die Quere kommen konnten.
Jetzt wird diese Kombination beim Start erkannt: GPS bleibt in dem Fall
deaktiviert (SBUS/RC-Verbindung hat Vorrang), eine deutliche Warnung
erscheint im seriellen Log **und** auf der Debug-Seite. Betroffen sind
nur SBUS-Nutzer mit V5 – bei CRSF/ELRS als RC-System besteht der Konflikt
nicht.

**Nicht übernommen** (bewusst geprüft, aber nicht nötig): Das
CRSF-Geräteerkennungs- und Parameterprotokoll dieses Moduls (inkl.
Wilhelm-Meier-Zeitschlitz-Schema gegen Kollisionen mehrerer Geräte am
Bus) ist bereits ausgereifter als der entsprechende Teil in
ESP32-GPS-Telemetry – hier bestand kein Nachholbedarf.

---



- Motorklangsimulation (Start, Loop, Abschalten) mit drehzahlabhängiger Abspielgeschwindigkeit
- 8 frei konfigurierbare Zusatzsounds (WAV-Dateien von SD-Karte)
- Unterstützung für SBUS (FrSky, FlySky, ELRS SBUS, Hott) und CRSF/ELRS
- Einkanal-Multiplexing (MultiSwitch-Protokoll, WM0–WM3)
- Ebenenumschaltung (bis zu 7 Ebenen × 3 Gruppen)
- Alle vier Hardware-Versionen (V1, V2, V3, V4) in einem Firmware-Image
- CRSF-Parametersystem (72 Parameter, vollständige Konfiguration über TBS Agent / ELRS-Lua)
- LiPo-Telemetrie über FrSky S.Port (Hardware V4)

---

## Neu in v2.2 (gegenüber v1.24)

- **Neue Hardware-Version V5** – baut auf V4 auf (BUS + Einkanal + S.Port-LiPo-Telemetrie) und ergänzt eine **GPS-Geschwindigkeitsmessung**.
- **GPS-Modul** (`gps_speed.cpp/.h`): liest ein NMEA-GPS (z. B. u-blox NEO-M8N/NEO-6M) über eine reine Empfangs-Software-Serial auf **GPIO 27** (PWM-Pin 4 der V4/V5-Platine) bei 9600 Baud. S.Port (GPIO 32/33) und CRSF (GPIO 16/17) bleiben unberührt.
- **Geschwindigkeit über CRSF-GPS-Telemetrie**: Die Ground Speed erscheint direkt als „GSpd" in der EdgeTX-Telemetrie (zusätzlich Position, Kurs, Satelliten).
- Hardware-Auswahl im Lua-Menü/Web um **V5** erweitert.
- Benötigte Bibliotheken für V5: **EspSoftwareSerial** und **TinyGPSPlus**.

> Hinweis: V5 nutzt weiterhin alle V4-Funktionen. Wird die Hardware-Version zur Laufzeit gewechselt, ist ein Neustart nötig, damit GPS/S.Port sauber initialisieren.

---

## Neu in v1.24 (gegenüber v1.23)

Diese Version macht die CRSF-Parametrierung (TBS Agent / ELRS-Lua) für den Betrieb **mehrerer Module am selben Empfänger** tauglich und behebt mehrere Fehler, die das Lua-Menü verhinderten:

- **Eindeutige CRSF-Geräteadresse aus der WM-Adresse** – die Adresse wird als `0xC0 + WM-Adresse` abgeleitet (WM0→0xC0, WM2→0xC2 …). Dadurch kollidiert das Modul nicht mehr mit anderen CRSF-Geräten (z. B. einem Wilhelm-Meier-Multiswitch), die sich sonst alle als 0xC8 melden würden
- **Ping-Answer-Slot nach Wilhelm-Meier-Schema** – die Antwort auf den Broadcast-Ping wird um einen aus der Adresse abgeleiteten Zeit-Slot verzögert (`Slot = (Adresse−0xC0)×2`, Dauer `CRSF_SLOT_MS`). So überlagern sich die Geräteantworten mehrerer Module nicht auf dem Downlink, und alle erscheinen getrennt im Agent
- **Parameter-IDs lückenlos gemacht** – die frühere Lücke bei ID 69/70 ist geschlossen (obere Parameter von 71–74 auf 69–72 nachgerückt), `CRSF_PARAM_COUNT` korrekt auf 72. Der ELRS-Lua-Agent fragt **alle** Parameter der Reihe nach ab; eine Lücke ließ das Menü komplett abbrechen
- **Absturz-Schutz beim Laufzeit-Wechsel der Hardware-Version** – wird Hardware_Config im Betrieb auf V4 gestellt, ohne dass S.Port initialisiert wurde, verhindert ein Null-Pointer-Check den Guru-Meditation-Absturz (S.Port arbeitet dann nach einem Neustart)
- **Versionsnummern vereinheitlicht** – in v1.23 stand in einigen Datei-Headern (`config`, `WebServerManager`) noch „v1.22"; alle Dateien tragen jetzt konsistent v1.24
- **Hinweis:** Beim Betrieb mehrerer Module müssen diese unterschiedliche WM-Adressen haben, und der Empfänger muss Nicht-0xC8-Adressen weiterleiten (ExpressLRS ab Version 4.x kann das)

---

## Neu in v1.23 (gegenüber v1.22)

- **S.Port-Empfangslogik korrigiert** – die Sensorantwort folgt direkt auf die Poll-ID (kein zweites Start-Byte); die State-Machine wurde entsprechend umgebaut
- **Cells-Dekodierung im FrSky/FLVSS-Format** (pawelsky-kompatibel): Einzelzellen werden korrekt aus dem 32-Bit-Datenwort dekodiert
- **Sensor-Zuordnung über die Poll-ID** – Pack 1 (0xA1) und Pack 2 (0x22) werden zuverlässig getrennt erfasst
- **Stabile Online-Erkennung** – gemeinsame Zeitbasis im Timeout-Check verhindert sporadisches Flackern der Sensoren
- **Einzelzellen-Telemetrie über CRSF-Voltages (0x0E)** – erscheinen in EdgeTX/OpenTX als „Cels"-Sensoren (ein Sensor je Pack)
- **Kein eigener Batterie-Frame mehr** – RxBt bleibt dadurch die vom Empfänger selbst gemessene Spannung und wird nicht mehr von der LiPo-Summe überschrieben
- **Verdrahtung:** 4,7-kΩ-Pull-Widerstand zwischen S.Port-Signal und GND dokumentiert (für stabile Telemetrie erforderlich)

---

## Neu in v1.22 (gegenüber v0.84)

- **Weboberfläche komplett neu** – vollständiges HTML/CSS/JS liegt als PROGMEM im Flash
  - Kein RAM-Allokation mehr pro Request (zuvor ~60 KB RAM pro Seitenaufruf)
  - `buildPage()` entfernt, `server.send_P()` streamt direkt aus dem Flash
  - Modernes Dark-Mode-UI (GitHub-Farbschema)
  - Responsive Design für Mobilgeräte
- Stabilitätsverbesserungen bei häufigen Webzugriffen

---

## Hardware-Versionen

| Version | GPIO-Pins (Eingänge) | Besonderheit |
|---|---|---|
| **V1** | 22, 0, 2, 4 | BUS + PWM-Eingang + GPIO-Pin + Einkanal |
| **V2** | 14, 27, 32, 33 | BUS + PWM-Eingang + GPIO-Pin + Einkanal |
| **V3** | – | Nur BUS-Kanal + Einkanal (SBUS/CRSF) |
| **V4** | – | Wie V3 + S.Port LiPo-Telemetrie |
| **V5** | 27 (GPS RX), 14 (GPS TX) | Wie V4 + GPS-Geschwindigkeitsmessung über CRSF |

---

## Pin-Belegung

### Alle Versionen

| GPIO | Funktion |
|---|---|
| 13 | WiFi-Aktivierung (LOW = AP-Modus) |
| 16 | CRSF RX / SBUS RX |
| 17 | CRSF TX |
| 05 | SD_CS |
| 18 | SD_CLK |
| 19 | SD_MISO |
| 23 | SD_MOSI |
| 21 | I2S_DOUT |
| 25 | I2S_LRC |
| 26 | I2S_BCLK |

### V1 – zusätzliche Eingänge

| GPIO | Funktion |
|---|---|
| 22, 0, 2, 4 | Input 3–6 (PWM/GPIO) |

### V2 – zusätzliche Eingänge

| GPIO | Funktion |
|---|---|
| 14, 27, 32, 33 | Input 3–6 (PWM/GPIO) |

### V4 – S.Port LiPo (zusätzlich)

| GPIO | Funktion |
|---|---|
| 32 | S.Port RX |
| 33 | S.Port TX |

> **Schaltung V4:** GPIO33 → Anode → [1N4148] → Kathode → S.Port Signal ← GPIO32
>
> Zusätzlich: **4,7 kΩ** zwischen S.Port-Signal und GND (Pull-Widerstand, hält die Leitung im Ruhezustand auf definiertem Pegel – für stabile Telemetrie erforderlich). Bei zwei Sensoren am selben Bus genügt ein Widerstand.

### V5 – GPS (zusätzlich zu V4)

| GPIO | Funktion |
|---|---|
| 27 | GPS TX → ESP32 RX (Empfang der NMEA-Daten) |
| 14 | ESP32 TX → GPS RX (Konfiguration, z. B. Updaterate) |

> NMEA-GPS-Modul (z. B. u-blox NEO-M8N/NEO-6M, ATGM336H) bei 9600 Baud, reine Software-Serial. S.Port (32/33) und CRSF (16/17) bleiben unberührt.

---

## Hardware-Voraussetzungen

| Komponente | Beschreibung |
|---|---|
| ESP32 | Board-Version 3.3.8 |
| SD-Karte | SPI-Anschluss |
| I2S-DAC/Verstärker | z. B. MAX98357A |
| RC-Empfänger | SBUS oder CRSF |
| LiPo-BMS mit S.Port | Nur für Hardware V4 |

---

## SD-Karten-Dateien

| Dateiname | Funktion |
|---|---|
| `loop.wav` | Motor-Laufgeräusch (Schleife) |
| `start.wav` | Motorstart-Geräusch |
| `shut.wav` | Motorabschalt-Geräusch |
| `sound1.wav` – `sound8.wav` | Zusatzsounds 1–8 |

---

## Bibliotheken

| Bibliothek | Version |
|---|---|
| Bolder Flight Systems SBUS | 8.1.4 |
| CRSF_ESP32 | https://github.com/Ziege-One/CRSF_ESP32 |

---

## Konfiguration

### Weboberfläche (alle Versionen)
1. GPIO 13 auf LOW ziehen
2. ESP32 startet als WLAN-Access-Point
3. Mit dem konfigurierten Netzwerk verbinden
4. Weboberfläche im Browser öffnen (modernes Dark-Mode-UI, mobilfreundlich)
5. Einstellungen anpassen und speichern

### TBS Agent / EdgeTX Lua (CRSF-Modus)
- 75 CRSF-Parameter in Ordnerstruktur: Motor, Sound 1–8, Einstellungen
- Hardware-Version umschaltbar (Neustart erforderlich)
- Sound-Test direkt aus dem Agent heraus möglich

---

## Quellentypen

| Code | Quelle | V1/V2 | V3/V4 |
|---|---|---|---|
| 0–15 | BUS-Kanal Low (1–16) | ✓ | ✓ |
| 20–35 | BUS-Kanal High (1–16) | ✓ | ✓ |
| 40–45 | PWM-Eingang Low (1–6) | ✓ | – |
| 50–55 | PWM-Eingang High (1–6) | ✓ | – |
| 60–65 | GPIO-Pin direkt (1–6) | ✓ | – |
| 70–77 | Einkanal-Bit (1–8) | ✓ | ✓ |
| 80–103 | Ebenen-Umschaltung | ✓ | ✓ |
| 200 | Dauerbetrieb | ✓ | ✓ |
| 999 | Deaktiviert | ✓ | ✓ |

---

## Versionshistorie

| Version | Highlights |
|---|---|
| v0.45 | NVS statt EEPROM, CRSF-Timeout-Failsafe |
| v0.70 | V1/V2/V3 vereint, CRSF-Parametersystem (75 Parameter) |
| v0.84 | Hardware V4, S.Port LiPo-Telemetrie, Einzelzellen-SoC |
| v1.22 | Weboberfläche als PROGMEM (Flash), ~60 KB RAM-Ersparnis pro Request, Dark-Mode-UI |
| v1.23 | S.Port-Empfangslogik korrigiert, FrSky/FLVSS-Zellendekodierung, CRSF-Voltages statt Batterie-Frame |
| v1.24 | Eindeutige CRSF-Geräteadresse je WM-Adresse, Wilhelm-Meier-Zeitschlitz-Schema, Parameter-IDs lückenlos (72) |
| v2.0 | Hardware V5 (GPS-Geschwindigkeitsmessung über CRSF-GPS-Telemetrie) |
| v2.2 | Granulare S.Port-/CRSF-Diagnosezähler im Debug-Tab (Learnings aus ESP32-GPS-Telemetry) |
| v2.21 | Bugfix: Ausschalten eines fertig gespielten Tipp-Sounds konnte die komplette Playliste (u.a. Motorsound) kappen |
| v2.22 | Bugfix: Web-UI zeigte nach Speichern von Sound-/Motor-Modus beim Tab-Wechsel wieder den alten Wert (nur Anzeige, Speicherung war korrekt) |
