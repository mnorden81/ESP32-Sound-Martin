# ESP32-RC-Sound v0.87

**Autor:** PiperPilot

> **Neu in v0.86 (gegenüber v0.85) – übertragen aus v1.24:**
> - **Eindeutige CRSF-Geräteadresse** aus der WM-Adresse (`0xC0 + WM-Adresse`) – erlaubt den Betrieb mehrerer CRSF-Konfigurationsgeräte am selben Empfänger, ohne Adresskonflikt
> - **Ping-Answer-Slot** (Wilhelm-Meier-Schema, `Slot = (Adresse−0xC0)×2`) – verhindert das Überlagern der Geräteantworten auf dem Downlink
> - **Absturz-Schutz** – Null-Check in `sportLipoUpdate()`, falls Hardware_Config zur Laufzeit auf V4 gestellt wird, bevor S.Port initialisiert ist
> - **Versionsnummern vereinheitlicht** auf v0.86
>
> Voraussetzung für Multi-Device-Betrieb: ExpressLRS ab Version 4.x. Die S.Port-Dekodierfixes (State-Machine, FLVSS-Format, Poll-ID-Zuordnung) sowie RxBt-vom-Empfänger und lückenlose Parameter-IDs waren in dieser Version bereits enthalten.


 Autor: PiperPilot
 Basiert auf Ziege-One (Der RC-Modellbauer)

ESP32-basiertes RC-Soundmodul mit I2S-Audioausgabe, SD-Karten-Wiedergabe, WLAN-Weboberfläche, CRSF-Parametersystem und optionaler LiPo-Telemetrie über S.Port (Hardware V4).

---

## Neu in v0.87 (gegenüber v0.86) — Bugfix

**Fehlerbild:** Der Motorsound (und andere gerade laufende Sounds) konnten
abrupt abbrechen, wenn ein Sound im **Tipp-Modus** (Mode_Sound==2)
ausgeschaltet wurde, nachdem er selbst schon fertig durchgespielt hatte.

**Ursache:** `handleSound()` ruft beim Loslassen eines Tipp-Sounds
unconditional `I2SAudio.Stop(snd)` auf, auch wenn dieser Sound sich
zuvor schon selbst (nach dem natürlichen Ende) aus der internen
Playliste entfernt hatte. `RemoveFromPlayList()` in `XT_I2S_Audio.cpp`
interpretierte einen Sound mit `PreviousItem == nullptr` und
`NextItem == nullptr` fälschlich als "einziger Eintrag in der Liste"
und setzte dadurch bedingungslos `FirstPlayListItem` und
`LastPlayListItem` auf `nullptr` — das kappte die komplette aktive
Playliste, unabhängig davon, was tatsächlich gerade lief (Motorsound,
andere Loop-Sounds, etc.).

**Fix:** `XT_I2S_Class::Stop()` prüft jetzt vorab mit `AlreadyPlaying()`,
ob der Sound überhaupt noch in der Playliste verlinkt ist, bevor
`RemoveFromPlayList()` aufgerufen wird (siehe `XT_I2S_Audio.cpp`).

---

## Funktionsübersicht

- Motorklangsimulation (Start, Loop, Abschalten) mit drehzahlabhängiger Abspielgeschwindigkeit
- 8 frei konfigurierbare Zusatzsounds (WAV-Dateien von SD-Karte)
- Unterstützung für SBUS (FrSky, FlySky, ELRS SBUS, Hott) und CRSF/ELRS
- Einkanal-Multiplexing (MultiSwitch-Protokoll, WM0–WM3)
- Ebenenumschaltung (bis zu 7 Ebenen × 3 Gruppen)
- **Alle vier Hardware-Versionen (V1, V2, V3, V4) in einem Firmware-Image**
- CRSF-Parametersystem (75 Parameter, vollständige Konfiguration über TBS Agent)
- **LiPo-Telemetrie** über FrSky S.Port (Hardware V4): Einzelzellen je Pack, in EdgeTX/OpenTX als „Cels"-Sensoren

---

## Neu in v0.85 (gegenüber v0.70)

- **Hardware V4** – wie V3, zusätzlich FrSky S.Port LiPo-Telemetrie (GPIO 32/33)
- **Zwei LiPo-Packs** werden unterstützt (je ein FrSky FLVSS-/MLVSS-Sensor pro Pack)
- **Korrekte FLVSS-Cells-Dekodierung** (pawelsky-kompatibel) – Einzelzellen werden sauber aus dem S.Port-Datenwort gelesen
- **Sensor-Zuordnung über die Poll-ID** – Pack 1 (0xA1) und Pack 2 (0x22) werden zuverlässig getrennt erfasst
- **Stabile Online-Erkennung** – gemeinsame Zeitbasis im Timeout-Check verhindert Flackern
- **Einzelzellen-Telemetrie über CRSF-Voltages (0x0E)** – erscheinen in EdgeTX/OpenTX als „Cels"-Sensoren (ein Sensor je Pack)
- **RxBt bleibt die Empfängermessung** – das Modul sendet keinen eigenen Batterie-Frame, sodass die vom Empfänger gemessene Spannung nicht überschrieben wird
- Neue `sport_lipo.cpp/.h`-Dateien für die S.Port-Kommunikation

---

## Hardware-Versionen

| Version | GPIO-Pins (Eingänge) | Besonderheit |
|---|---|---|
| **V1** | 22, 0, 2, 4 | BUS + PWM-Eingang + GPIO-Pin + Einkanal |
| **V2** | 14, 27, 32, 33 | BUS + PWM-Eingang + GPIO-Pin + Einkanal |
| **V3** | – | Nur BUS-Kanal + Einkanal (SBUS/CRSF) |
| **V4** | – | Wie V3 + S.Port LiPo-Telemetrie |

---

## Pin-Belegung

### Alle Versionen

| GPIO | Funktion |
|---|---|
| 13 | WiFi-Aktivierung (LOW = AP-Modus) |
| 16 | CRSF RX / SBUS RX |
| 17 | CRSF TX |
| 05 | SD_CS |
| 18 | SD_CLK |
| 19 | SD_MISO |
| 23 | SD_MOSI |
| 21 | I2S_DOUT |
| 25 | I2S_LRC |
| 26 | I2S_BCLK |

### V1 – zusätzliche Eingänge

| GPIO | Funktion |
|---|---|
| 22, 0, 2, 4 | Input 3–6 (PWM/GPIO) |

### V2 – zusätzliche Eingänge

| GPIO | Funktion |
|---|---|
| 14, 27, 32, 33 | Input 3–6 (PWM/GPIO) |

### V4 – S.Port LiPo (zusätzlich)

| GPIO | Funktion |
|---|---|
| 32 | S.Port RX |
| 33 | S.Port TX |

> **Schaltung V4:** GPIO33 → Anode → [1N4148] → Kathode → S.Port Signal ← GPIO32
>
> Zusätzlich: **4,7 kΩ** zwischen S.Port-Signal und GND (Pull-Widerstand, hält die Leitung im Ruhezustand auf definiertem Pegel – für stabile Telemetrie erforderlich). Bei zwei Sensoren am selben Bus genügt ein Widerstand.

---

## Hardware-Voraussetzungen

| Komponente | Beschreibung |
|---|---|
| ESP32 | Board-Version 3.3.8 |
| SD-Karte | SPI-Anschluss |
| I2S-DAC/Verstärker | z. B. MAX98357A |
| RC-Empfänger | SBUS oder CRSF |
| LiPo-BMS mit S.Port | Nur für Hardware V4 |

---

## SD-Karten-Dateien

| Dateiname | Funktion |
|---|---|
| `loop.wav` | Motor-Laufgeräusch (Schleife) |
| `start.wav` | Motorstart-Geräusch |
| `shut.wav` | Motorabschalt-Geräusch |
| `sound1.wav` – `sound8.wav` | Zusatzsounds 1–8 |

---

## Bibliotheken

| Bibliothek | Version |
|---|---|
| Bolder Flight Systems SBUS | 8.1.4 |
| CRSF_ESP32 | https://github.com/Ziege-One/CRSF_ESP32 |

---

## Konfiguration

### Weboberfläche (alle Versionen)
1. GPIO 13 auf LOW ziehen
2. ESP32 startet als WLAN-Access-Point
3. Mit dem konfigurierten Netzwerk verbinden und Weboberfläche öffnen

### TBS Agent / EdgeTX Lua (CRSF-Modus)
- 75 CRSF-Parameter in Ordnerstruktur: Motor, Sound 1–8, Einstellungen
- Hardware-Version umschaltbar (Neustart erforderlich)
- Sound-Test direkt aus dem Agent heraus möglich

---

## Quellentypen

| Code | Quelle | V1/V2 | V3/V4 |
|---|---|---|---|
| 0–15 | BUS-Kanal Low (1–16) | ✓ | ✓ |
| 20–35 | BUS-Kanal High (1–16) | ✓ | ✓ |
| 40–45 | PWM-Eingang Low (1–6) | ✓ | – |
| 50–55 | PWM-Eingang High (1–6) | ✓ | – |
| 60–65 | GPIO-Pin direkt (1–6) | ✓ | – |
| 70–77 | Einkanal-Bit (1–8) | ✓ | ✓ |
| 80–103 | Ebenen-Umschaltung | ✓ | ✓ |
| 200 | Dauerbetrieb | ✓ | ✓ |
| 999 | Deaktiviert | ✓ | ✓ |
