# ESP32-RC-Sound v0.46

**Autor:** Ziege-One (Der RC-Modellbauer)

ESP32-basiertes RC-Soundmodul mit I2S-Audioausgabe, SD-Karten-Wiedergabe und Konfiguration über WLAN-Weboberfläche.

---

## Neu in v0.46 (gegenüber v0.45) — Bugfix

**Fehlerbild:** Der Motorsound (und andere gerade laufende Sounds) konnten
abrupt abbrechen, wenn ein Sound im **Tipp-Modus** (Mode_Sound==2)
ausgeschaltet wurde, nachdem er selbst schon fertig durchgespielt hatte.

**Ursache:** `handleSound()` ruft beim Loslassen eines Tipp-Sounds
unconditional `I2SAudio.Stop(snd)` auf, auch wenn dieser Sound sich
zuvor schon selbst (nach dem natürlichen Ende) aus der internen
Playliste entfernt hatte. `RemoveFromPlayList()` in `XT_I2S_Audio.cpp`
interpretierte einen Sound mit `PreviousItem == nullptr` und
`NextItem == nullptr` fälschlich als "einziger Eintrag in der Liste"
und setzte dadurch bedingungslos `FirstPlayListItem` und
`LastPlayListItem` auf `nullptr` — das kappte die komplette aktive
Playliste, unabhängig davon, was tatsächlich gerade lief (Motorsound,
andere Loop-Sounds, etc.).

**Fix:** `XT_I2S_Class::Stop()` prüft jetzt vorab mit `AlreadyPlaying()`,
ob der Sound überhaupt noch in der Playliste verlinkt ist, bevor
`RemoveFromPlayList()` aufgerufen wird (siehe `XT_I2S_Audio.cpp`).

---

## Funktionsübersicht

- Motorklangsimulation (Start, Loop, Abschalten) mit drehzahlabhängiger Abspielgeschwindigkeit
- 8 frei konfigurierbare Zusatzsounds (WAV-Dateien von SD-Karte)
- Unterstützung für SBUS (FrSky, FlySky, ELRS, Hott) und CRSF/ELRS
- Einkanal-Multiplexing (MultiSwitch-Protokoll, WM0–WM3)
- Ebenenumschaltung (bis zu 7 Ebenen × 3 Gruppen)
- WLAN-Weboberfläche zur Konfiguration (Access-Point-Modus)
- Konfigurationsspeicherung im NVS (Non-Volatile Storage, verschleißarm)

---

## Neu in v0.45

- **NVS statt EEPROM** – robustere, verschleißschonende Konfigurationsspeicherung
- **configDirty-Flag** – Flash wird nur bei tatsächlicher Änderung beschrieben
- **CRSF-Timeout-Failsafe** – `BUS_OK` wird nach 2 s auf `false` gesetzt, wenn kein CRSF-Paket eingeht
- **Bugfix:** `BUS_OK` im CRSF-Modus nicht mehr pauschal `true`

---

## Hardware-Voraussetzungen

| Komponente | Beschreibung |
|---|---|
| ESP32 | Board-Version 3.3.8 |
| SD-Karte | SPI-Anschluss (CS, CLK, MISO, MOSI) |
| I2S-DAC/Verstärker | z. B. MAX98357A |
| RC-Empfänger | SBUS oder CRSF |

### Pin-Belegung

| GPIO | Funktion (V1) | Funktion (V2) |
|---|---|---|
| 13 | WiFi-Aktivierung (LOW = AP-Modus) | |
| 16 | Input 1 / SBUS RX | Input 1 |
| 17 | Input 2 | Input 2 |
| 22 | Input 3 (V1) | – |
| 00 | Input 4 (V1) | – |
| 02 | Input 5 (V1) | – |
| 04 | Input 6 (V1) | – |
| 14 | – | Input 3 (V2) |
| 27 | – | Input 4 (V2) |
| 32 | – | Input 5 (V2) |
| 33 | – | Input 6 (V2) |
| 05 | SD_CS | |
| 18 | SD_CLK | |
| 19 | SD_MISO | |
| 23 | SD_MOSI | |
| 21 | I2S_DOUT | |
| 25 | I2S_LRC | |
| 26 | I2S_BCLK | |

---

## SD-Karten-Dateien

Die folgenden WAV-Dateien müssen im Wurzelverzeichnis der SD-Karte vorhanden sein:

| Dateiname | Funktion |
|---|---|
| `loop.wav` | Motor-Laufgeräusch (wird in Schleife abgespielt) |
| `start.wav` | Motorstart-Geräusch |
| `shut.wav` | Motorabschalt-Geräusch |
| `sound1.wav` – `sound8.wav` | Zusatzsounds 1–8 |

---

## Bibliotheken

| Bibliothek | Version |
|---|---|
| Bolder Flight Systems SBUS | 8.1.4 |
| CRSF_ESP32 | https://github.com/Ziege-One/CRSF_ESP32 |

---

## Konfiguration (Weboberfläche)

1. GPIO 13 auf LOW ziehen (Jumper/Taster)
2. ESP32 startet als WLAN-Access-Point
3. Mit dem konfigurierten WLAN-Netzwerk verbinden
4. Weboberfläche im Browser öffnen
5. Einstellungen anpassen und speichern

---

## Quellentypen

| Code | Quelle |
|---|---|
| 0–15 | BUS-Kanal Low (1–16) |
| 20–35 | BUS-Kanal High (1–16) |
| 40–45 | PWM-Eingang Low (1–6) |
| 50–55 | PWM-Eingang High (1–6) |
| 60–65 | GPIO-Pin direkt (1–6) |
| 70–77 | Einkanal-Bit (1–8) |
| 80–103 | Ebenen-Umschaltung |
| 200 | Dauerbetrieb |
| 999 | Deaktiviert |
