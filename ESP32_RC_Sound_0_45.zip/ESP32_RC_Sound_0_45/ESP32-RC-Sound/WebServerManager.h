#pragma once
#include <WiFi.h>

class WebServerManager {
public:
  // begin startet AP (oder verbindet, je nach Implementierung) und startet den Server
  static void begin(const char* apSsid, const char* apPassword);

  // in loop() aufrufen, bearbeitet anstehende Clients
  static void Webpage();

private:
  static WiFiServer server;
  static String header;
  static String valueString;
  // FIX: pos1/pos2 entfernt – Parameter-Extraktion jetzt via extractValue()
  static int Menu;
  static unsigned long previousTime;
  static unsigned long currentTime;
  static const long timeoutTime;
};
