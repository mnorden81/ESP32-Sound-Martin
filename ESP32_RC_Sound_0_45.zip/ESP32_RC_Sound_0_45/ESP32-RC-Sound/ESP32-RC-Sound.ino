/*
   ESP32-RC-Sound  v0.45
   Ziege-One (Der RC-Modellbauer)

   ÄNDERUNGEN v0.45:
   - NVS statt EEPROM (über config.cpp): verschleißschonender, robuster
   - configDirty-Flag: Flash wird nur bei tatsächlicher Änderung beschrieben
   - CRSF-Timeout-Failsafe ergänzt (analog MultiSwitch v0.13):
       BUS_OK wird nach CRSF_TIMEOUT_MS auf false gesetzt wenn kein neues Paket
   - BUS_OK im CRSF-Modus nicht mehr pauschal true (war Fehler in v0.44)
   - Alle FIX-Kommentare aus v0.44 beibehalten

 ESP32 + SD + I2S Audio

 /////Pin Belegung////
 GPIO 13: Wifi Pin
 GPIO 14:               Input 3 (V2)
 GPIO 27:               Input 4 (V2)
 GPIO 33:               Input 5 (V2) 
 GPIO 32:               Input 6 (V2) 
 GPIO 15: 
 GPIO 16: Input 1 (V1)  Input 1 (V2)
 GPIO 17: Input 2 (V1)  Input 2 (V2)
 GPIO 22: Input 3 (V1)
 GPIO 00: Input 4 (V1)
 GPIO 02: Input 5 (V1)
 GPIO 04: Input 6 (V1)

 GPIO 05: SD_CS
 GPIO 18: SD_CLK  
 GPIO 19: SD_MISO
 GPIO 23: SD_MOSI

 GPIO 21: I2S_DOUT
 GPIO 25: I2S_LRC
 GPIO 26: I2S_BCLK
 */

// ======== ESP32-RC-Sound =======================================

/* Boardversion
ESP32                                         3.3.8
 */

/* Installierte Bibliotheken
Bolder Flight Systems SBUS                    8.1.4
CRSF_ESP32                                    https://github.com/Ziege-One/CRSF_ESP32
 */

#include <Arduino.h>
#include "XT_I2S_Audio.h"
#include <WiFi.h>
#include "sbus.h"
#include "crsf_esp32.h"
#include "config.h"
#include "WebServerManager.h"

// Software Version
uint16_t Version = 45;
char versionString[6];

// ---- Zustandsarrays -------------------------------------------------
bool Source_Start_Sound_OK[9] = {};
bool Sound_on[9]              = {};
bool Sound_play[9]            = {};
bool Sound_on_web[9]          = {};

// ---- Motor ----------------------------------------------------------
bool Sound_on_Motor       = false;
bool Sound_on_Motor_state = false;
bool engine_break         = false;
unsigned long shutdown_timer = 0;

enum Engine_State : uint8_t { OFF, STARTING, RUNNING, STOPPING };
volatile uint8_t engine_State = OFF;

// ---- EinKanalModus --------------------------------------------------
int      Einkanal_RC_System_boot = 0;
uint16_t einkanal_Data           = 0;
uint16_t einkanal_SpeicherWM     = 0;

// ---- EbenenUmschaltung ----------------------------------------------
int      Source_Ebenen_Um_Kanal_wert = 0;
int      Source_Ebenen_Kanal_wert    = 0;
uint16_t ebenenkanal_Data            = 99;

// ---- SD & I2S Pins --------------------------------------------------
#define SD_CS    5
#define I2S_DOUT 21
#define I2S_BCLK 26
#define I2S_LRC  25

// ---- GPIO Pins ------------------------------------------------------
const uint8_t WifiPin = 13;
const uint8_t LedPin  = 2;
uint8_t Input_Pin[6]  = {16, 17, 22, 0, 2, 4};

// ---- Throttle / Rampe -----------------------------------------------
unsigned long previousTime_ramp = 0;
float last_throttle = 0.0f;
float throttle      = 0.0f;

// ---- WiFi (aus config) ----------------------------------------------
char ssid[32];
char password[64];

// ---- Timing ---------------------------------------------------------
unsigned long currentTime  = 0;
unsigned long previousTime = 0;

// ---- SBUS -----------------------------------------------------------
bfs::SbusRx   sbus_rx(&Serial2, 16, 27, true);
bfs::SbusData sbus_data;
bool BUS_OK = false;

// ---- CRSF -----------------------------------------------------------
CRSF crsf;
#define MWset   0x01
#define MWprop  0x02
#define MWset4  0x07
#define MWset4m 0x09
#define Multiswitch 0xA1

// ---- CRSF-Timeout (NEU v0.45) ---------------------------------------
// Analog zu MultiSwitch v0.13: BUS_OK wird false wenn kein Paket kommt
static constexpr unsigned long CRSF_TIMEOUT_MS = 2000;
static unsigned long lastCrsfPacket = 0;

static void checkCrsfTimeout() {
    if (Einkanal_RC_System_boot != 4) return;
    if (millis() - lastCrsfPacket > CRSF_TIMEOUT_MS) {
        BUS_OK = false;
    }
}

// ---- Kanalwerte Speicher --------------------------------------------
uint16_t channel_output[16] = {};

// ---- WM-Prop Lautstärke-Speicher (MWprop Kanal 1-8) ----------------
uint8_t wm_prop_value[8] = {255, 255, 255, 255, 255, 255, 255, 255};

// ---- I2S Audio Instanz ----------------------------------------------
XT_I2S_Class I2SAudio(I2S_LRC, I2S_BCLK, I2S_DOUT, I2S_NUM_0);

// ---- Sound Objekte --------------------------------------------------
XT_Wav_Class Sound_loop ("/loop.wav");
XT_Wav_Class Sound_shut ("/shut.wav");
XT_Wav_Class Sound_start("/start.wav");
XT_Wav_Class Sound1("/sound1.wav");
XT_Wav_Class Sound2("/sound2.wav");
XT_Wav_Class Sound3("/sound3.wav");
XT_Wav_Class Sound4("/sound4.wav");
XT_Wav_Class Sound5("/sound5.wav");
XT_Wav_Class Sound6("/sound6.wav");
XT_Wav_Class Sound7("/sound7.wav");
XT_Wav_Class Sound8("/sound8.wav");

XT_Wav_Class* Sounds[9] = {
  nullptr,
  &Sound1, &Sound2, &Sound3, &Sound4,
  &Sound5, &Sound6, &Sound7, &Sound8
};

// ---- PWM Interrupt --------------------------------------------------
volatile unsigned int PWM_pulse_width[6] = {3000, 3000, 3000, 3000, 3000, 3000};
volatile unsigned int PWM_prev_time[6]   = {0, 0, 0, 0, 0, 0};

static inline void IRAM_ATTR handlePWM(uint8_t idx) {
  if (digitalRead(Input_Pin[idx])) {
    PWM_prev_time[idx]  = micros();
  } else {
    PWM_pulse_width[idx] = micros() - PWM_prev_time[idx];
  }
}
void IRAM_ATTR ISR_PWM_0() { handlePWM(0); }
void IRAM_ATTR ISR_PWM_1() { handlePWM(1); }
void IRAM_ATTR ISR_PWM_2() { handlePWM(2); }
void IRAM_ATTR ISR_PWM_3() { handlePWM(3); }
void IRAM_ATTR ISR_PWM_4() { handlePWM(4); }
void IRAM_ATTR ISR_PWM_5() { handlePWM(5); }

void (*ISR_PWM[6])() = {ISR_PWM_0, ISR_PWM_1, ISR_PWM_2, ISR_PWM_3, ISR_PWM_4, ISR_PWM_5};

static bool pwm_interrupt_attached[6] = {};
void attachPWM_ISR(uint8_t pinIdx) {
  if (pinIdx < 6 && !pwm_interrupt_attached[pinIdx]) {
    attachInterrupt(digitalPinToInterrupt(Input_Pin[pinIdx]), ISR_PWM[pinIdx], CHANGE);
    pwm_interrupt_attached[pinIdx] = true;
  }
}

// ======== Vorwärtsdeklarationen ======================================
void Config();
void SDCardInit();
void LoadFiles();
void ebenenFunction();
void einkanalFunction(uint16_t channel);
void einkanalFunctionCRSF();
uint8_t compressSwitches(uint16_t state);
float ramp_throttle(float throttle_new);
float floatMap(float x, float in_min, float in_max, float out_min, float out_max);
void handleSound(uint8_t idx, XT_Wav_Class* snd);
int16_t getVolume(uint8_t idx);

// ======== Setup ======================================================
void setup()
{
  Serial.begin(115200);

  loadConfig();

  strncpy(ssid,     config.WiFi_SSID,     sizeof(ssid)     - 1); ssid[sizeof(ssid)-1]         = '\0';
  strncpy(password, config.WiFi_Password, sizeof(password) - 1); password[sizeof(password)-1] = '\0';

  if (config.Einkanal_RC_System == 4) {
    crsf.init_crsf(&Serial1, 16, 22);
  } else {
    sbus_rx.Begin();
  }

  if (config.Hardware_Config == 0) {
    Serial.println("Config V1");
    uint8_t pins[] = {16, 17, 22, 0, 2, 4};
    memcpy(Input_Pin, pins, sizeof(pins));
  } else if (config.Hardware_Config == 1) {
    Serial.println("Config V2");
    uint8_t pins[] = {16, 17, 14, 27, 32, 33};
    memcpy(Input_Pin, pins, sizeof(pins));
  }

  pinMode(WifiPin, INPUT_PULLUP);
  for (uint8_t i = 1; i < 6; i++) {
    pinMode(Input_Pin[i], INPUT_PULLUP);
  }

  SDCardInit();
  LoadFiles();

  if (!digitalRead(WifiPin)) {
    Serial.println("AP (Zugangspunkt) einstellen...");
    WebServerManager::begin(ssid, password);
  } else {
    Serial.println("Normalmodus – kein AP");
  }

  Einkanal_RC_System_boot = config.Einkanal_RC_System;

  sprintf(versionString, "%d.%02d", Version / 100, Version % 100);

  // Beim ersten Start NVS befüllen (wenn configDirty noch true nach loadConfig)
  saveConfig();
}

// ======== Loop =======================================================
void loop()
{
  currentTime = millis();

  if (!digitalRead(WifiPin)) {
    WebServerManager::Webpage();
  }

  // ---- RC-Eingabe lesen ----
  if (Einkanal_RC_System_boot == 4) {
    // CRSF
    crsf.read_packets(0);

    for (int i = 0; i < 16; i++) {
      channel_output[i] = crsf.get_crfs_channels(i);
    }

    // NEU v0.45: CRSF-Timeout prüfen
    if (channel_output[0] > 0) {
      BUS_OK = true;
      lastCrsfPacket = millis();
    }
    checkCrsfTimeout();

    if (crsf.getDeviceCommandReplyPending()) {
      crsf.setDeviceCommandReplyPending(false);
      einkanalFunctionCRSF();
    }

  } else {
    // SBUS
    if (sbus_rx.Read()) {
      sbus_data = sbus_rx.data();
      BUS_OK = true;

      if (!sbus_data.failsafe) {
        if (config.Einkanal_Channel < 16 && config.Einkanal_mode != 999) {
          einkanalFunction(sbus_data.ch[config.Einkanal_Channel]);
        }
      } else {
        BUS_OK = false;
      }

      for (int i = 0; i < 16; i++) {
        channel_output[i] = sbus_data.ch[i];
      }
    }
  }

  // Dirty-Flag: NVS nur bei Bedarf schreiben (NEU v0.45)
  saveConfig();

  Config();

  if (currentTime < 5000) return;

  ebenenFunction();

  for (uint8_t i = 1; i <= 8; i++) {
    handleSound(i, Sounds[i]);
  }

  // ---- Motor Toggle-Logik ----
  if (Sound_on[0] && !Sound_on_Motor_state && config.engine_on_toggle) {
    Sound_on_Motor       = !Sound_on_Motor;
    Sound_on_Motor_state = true;
  } else if (!Sound_on[0] && Sound_on_Motor_state && config.engine_on_toggle) {
    Sound_on_Motor_state = false;
  } else if (!config.engine_on_toggle) {
    Sound_on_Motor = Sound_on[0];
  }

  bool motorWanted = Sound_on_Motor || Sound_on_web[0];

  if ((motorWanted && !engine_break && !Sound_play[0]) ||
      (throttle > 0 && engine_break && !Sound_play[0]) ||
      (throttle > 0 && Sound_play[0])) {
    Sound_play[0]  = true;
    shutdown_timer = millis();
  }

  if (!Sound_on_Motor && !Sound_on_web[0]) {
    Sound_play[0] = false;
    engine_break  = false;
  }

  if (config.shutdowndelay > 0 && Sound_play[0] &&
      (millis() - shutdown_timer) > ((unsigned long)config.shutdowndelay * 1000UL)) {
    Sound_play[0] = false;
    engine_break  = true;
  }

  // ---- Motor Schrittkette ----
  switch (engine_State) {
    case OFF:
      if (Sound_play[0]) {
        Sound_start.Volume = config.Volumen_Sound[0];
        I2SAudio.Play(&Sound_start);
        engine_State = STARTING;
      }
      break;
    case STARTING:
      if (!Sound_start.Playing) {
        throttle      = 0;
        last_throttle = 0;
        Sound_loop.RepeatForever = true;
        Sound_loop.Volume        = config.Volumen_Sound[0];
        I2SAudio.Play(&Sound_loop);
        engine_State = RUNNING;
      }
      break;
    case RUNNING:
      if (!Sound_play[0]) {
        throttle = 0;
        if (last_throttle == 0) {
          Sound_loop.RepeatForever = false;
          I2SAudio.Stop(&Sound_loop);
          engine_State = STOPPING;
        }
      }
      break;
    case STOPPING:
      if (!Sound_loop.Playing) {
        Sound_loop.RepeatForever = false;
        Sound_shut.Volume        = config.Volumen_Sound[0];
        I2SAudio.Play(&Sound_shut);
        engine_State = OFF;
      }
      break;
  }

  throttle = ramp_throttle(throttle);
  if (config.Min_Speed_Sound_0 != config.Max_Speed_Sound_0) {
    Sound_loop.Speed = floatMap(throttle, 0, 100,
                                config.Min_Speed_Sound_0,
                                config.Max_Speed_Sound_0) / 100.0f;
  }
}

// ======== Lautstärke-Quelle auflösen ================================
int16_t getVolume(uint8_t idx) {
  int src = config.Volumen_Source[idx];
  if (src >= 0 && src <= 15) {
    return (int16_t)constrain(map(channel_output[src], 172, 1811, 0, 200), 0, 200);
  } else if (src >= 200 && src <= 207) {
    uint8_t ch = src - 200;
    return (int16_t)map(wm_prop_value[ch], 0, 255, 0, 200);
  } else {
    return (int16_t)config.Volumen_Sound[idx];
  }
}

// ======== Sound 1-8 generisch verwalten ==============================
void handleSound(uint8_t idx, XT_Wav_Class* snd) {
  if (!snd) return;
  if (Sound_on[idx] || Sound_on_web[idx]) {
    snd->Volume = getVolume(idx);
    if (!Sound_play[idx]) {
      Sound_play[idx] = true;
      snd->LoadWavFile();
      if (config.Mode_Sound[idx] == 1) snd->RepeatForever = true;
      I2SAudio.Play(snd);
      Sound_on_web[idx] = false;
    }
  } else {
    snd->RepeatForever = false;
    if (config.Mode_Sound[idx] == 2 && Sound_play[idx]) I2SAudio.Stop(snd);
    if (!snd->Playing && Sound_play[idx]) {
      snd->UnLoadWavFile();
      Sound_play[idx] = false;
    }
  }
}

// ======== Config: Quellen auswerten ==================================
void Config() {
  unsigned int duration;

  for (int x = 0; x <= 8; x++) {
    Source_Start_Sound_OK[x] = false;
    int src = config.Source_Start_Sound[x];

    if (src < 20) {
      if (BUS_OK && src >= 0) {
        Source_Start_Sound_OK[x] = true;
        Sound_on[x] = (channel_output[src] < 624);
      }
    } else if (src < 40) {
      if (BUS_OK) {
        Source_Start_Sound_OK[x] = true;
        Sound_on[x] = (channel_output[src - 20] > 1424);
      }
    } else if (src < 50) {
      uint8_t pinIdx = src - 40;
      if (pinIdx < 6) {
        attachPWM_ISR(pinIdx);
        duration = PWM_pulse_width[pinIdx];
        if (duration < 2600) {
          Source_Start_Sound_OK[x] = true;
          int mapped = map(duration, config.PWM_scale_min, config.PWM_scale_max, 0, 100);
          Sound_on[x] = (mapped < 25);
        }
      }
    } else if (src < 60) {
      uint8_t pinIdx = src - 50;
      if (pinIdx < 6) {
        attachPWM_ISR(pinIdx);
        duration = PWM_pulse_width[pinIdx];
        if (duration < 2600) {
          Source_Start_Sound_OK[x] = true;
          int mapped = map(duration, config.PWM_scale_min, config.PWM_scale_max, 0, 100);
          Sound_on[x] = (mapped > 75);
        }
      }
    } else if (src < 70) {
      uint8_t pinIdx = src - 60;
      if (pinIdx < 6) {
        Source_Start_Sound_OK[x] = true;
        Sound_on[x] = !digitalRead(Input_Pin[pinIdx]);
      }
    } else if (src < 80) {
      if (BUS_OK) {
        Source_Start_Sound_OK[x] = true;
        Sound_on[x] = bitRead(einkanal_Data, src - 70);
      }
    } else if (src < 110) {
      Sound_on[x] = ((src - 80) == ebenenkanal_Data);
    } else if (src < 201) {
      Sound_on[x] = true;
    } else {
      Sound_on[x] = false;
    }
  }

  int spd = config.Source_Speed_Sound_0;
  if (spd < 20) {
    throttle = map(channel_output[spd], 82, 1900, 0, 100);
  } else if (spd < 26) {
    uint8_t pinIdx = spd - 20;
    attachPWM_ISR(pinIdx);
    duration = PWM_pulse_width[pinIdx];
    throttle = map((long)duration, config.PWM_scale_min, config.PWM_scale_max, 0, 100);
  }

  throttle = constrain(throttle, 0, 100);

  if (config.throttle_mode) {
    if (throttle > 50 + config.throttle_dead_band) {
      throttle = map((long)throttle, 50 + config.throttle_dead_band, 100, 0, 100);
    } else if (throttle < 50 - config.throttle_dead_band) {
      throttle = map((long)throttle, 50 - config.throttle_dead_band, 0, 0, 100);
    } else {
      throttle = 0;
    }
  } else {
    if (throttle > config.throttle_dead_band) {
      throttle = map((long)throttle, config.throttle_dead_band, 100, 0, 100);
    } else {
      throttle = 0;
    }
  }

  throttle = constrain(throttle, 0, 100);
}

// ======== Float Map ==================================================
float floatMap(float x, float in_min, float in_max, float out_min, float out_max) {
  if (in_max == in_min) return out_min;
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

// ======== SD Card Init ===============================================
void SDCardInit() {
  pinMode(SD_CS, OUTPUT);
  digitalWrite(SD_CS, HIGH);
  if (!SD.begin(SD_CS)) {
    Serial.println("FEHLER: SD-Karte nicht lesbar!");
  }
}

// ======== LoadFiles ==================================================
void LoadFiles() {
  Sound_loop.LoadWavFile();
  Sound_shut.LoadWavFile();
  Sound_start.LoadWavFile();
}

// ======== Throttle-Rampe =============================================
float ramp_throttle(float throttle_new) {
  unsigned long RampTime  = currentTime - previousTime_ramp;
  previousTime_ramp       = currentTime;
  if (RampTime > 1000) RampTime = 1000;
  float throttle_ramp_f   = (float)config.throttle_ramp;
  float throttle_ramp_now = (throttle_ramp_f / 1000.0f) * (float)RampTime;
  if (throttle_new > last_throttle) {
    float stepped = last_throttle + throttle_ramp_now;
    throttle_new = (stepped < throttle_new) ? stepped : throttle_new;
  } else {
    float stepped = last_throttle - throttle_ramp_now;
    throttle_new = (stepped > throttle_new) ? stepped : throttle_new;
  }
  last_throttle = throttle_new;
  return throttle_new;
}

// ======== Einkanal SBUS ==============================================
void einkanalFunction(uint16_t channel) {
  einkanal_Data = channel;
  if (config.Einkanal_mode == 0) {
    einkanal_Data = einkanal_Data / 8;
  } else if (config.Einkanal_mode <= 9) {
    if (config.Einkanal_RC_System == 0) {
      einkanal_Data = einkanal_Data / 8;
    } else if (config.Einkanal_RC_System == 1) {
      einkanal_Data = constrain(einkanal_Data, 206, 1837);
      einkanal_Data = ((einkanal_Data - 206) * 10 + 20) / 64;
    } else if (config.Einkanal_RC_System == 2) {
      float v = ((float)einkanal_Data - 172.0f + 1.5f) * 0.155677655677655f;
      einkanal_Data = (uint16_t)v;
    }
  } else {
    uint16_t n = 0;
    uint8_t  v = 0;
    switch (config.Einkanal_RC_System) {
      case 0: n = (channel >= 172) ? (channel - 172 + 1) : 0; v = (uint8_t)(n >> 4); break;
      case 1: n = (channel >= 220) ? (channel - 220) : 0; v = (uint8_t)((n + (n >> 6)) >> 4); break;
      case 2: n = (channel >= 172) ? (channel - 172) : 0; v = (uint8_t)(n >> 4); break;
      case 3: n = (channel >= 205) ? (channel - 205) : 0; v = (uint8_t)(n >> 4); break;
    }
    uint8_t address = (v >> 4) & 0b11;
    uint8_t sw      = (v >> 1) & 0b111;
    uint8_t state   = v & 0b1;
    if (address == (uint8_t)(config.Einkanal_mode - 10)) {
      bitWrite(einkanal_SpeicherWM, sw, state);
    }
    einkanal_Data = einkanal_SpeicherWM;
  }
}

// ======== Einkanal CRSF ==============================================
void einkanalFunctionCRSF() {
  uint8_t WMcode  = crsf.get_crfs_buffer(5);
  uint8_t command = crsf.get_crfs_buffer(6);
  if (WMcode != Multiswitch) return;
  switch (command) {
    case MWset4: {
      uint8_t address = crsf.get_crfs_buffer(7);
      if (address == (uint8_t)config.modul_adress) {
        uint16_t state = ((uint16_t)crsf.get_crfs_buffer(8) << 8) | crsf.get_crfs_buffer(9);
        einkanal_Data = compressSwitches(state);
      }
      break;
    }
    case MWset4m: {
      uint8_t count = crsf.get_crfs_buffer(7);
      if (count > 7) count = 7;
      for (uint8_t i = 0; i < count; i++) {
        uint8_t address = crsf.get_crfs_buffer(8 + (3 * i));
        if (address == (uint8_t)config.modul_adress) {
          uint16_t state = ((uint16_t)crsf.get_crfs_buffer(9 + (3 * i)) << 8)
                         |              crsf.get_crfs_buffer(10 + (3 * i));
          einkanal_Data = compressSwitches(state);
        }
      }
      break;
    }
    case MWprop: {
      uint8_t address = crsf.get_crfs_buffer(7);
      if (address == (uint8_t)config.modul_adress) {
        uint8_t channel = crsf.get_crfs_buffer(8);
        uint8_t duty    = crsf.get_crfs_buffer(9);
        if (channel < 8) wm_prop_value[channel] = duty;
      }
      break;
    }
  }
}

// ======== Switch-Komprimierung =======================================
uint8_t compressSwitches(uint16_t state) {
  uint8_t result = 0;
  for (uint8_t i = 0; i < 8; i++) result |= ((state >> (i * 2)) & 0x1) << i;
  return result;
}

// ======== EbenenUmschaltung ==========================================
void ebenenFunction() {
  Source_Ebenen_Um_Kanal_wert = 1;
  Source_Ebenen_Kanal_wert    = 0;

  int umSrc = config.Source_Ebenen_Um_Kanal;
  int kSrc  = config.Source_Ebenen_Kanal;

  if (umSrc < 20) {
    Source_Ebenen_Um_Kanal_wert = map(channel_output[umSrc], 207, 1833, 0, 100);
  } else if (umSrc >= 20 && umSrc < 26) {
    attachPWM_ISR(umSrc - 20);
    Source_Ebenen_Um_Kanal_wert = map((long)PWM_pulse_width[umSrc - 20], 938, 2063, 0, 100);
  }

  if (kSrc < 20) {
    Source_Ebenen_Kanal_wert = map(channel_output[kSrc], 207, 1833, 0, 100);
  } else if (kSrc >= 20 && kSrc < 26) {
    attachPWM_ISR(kSrc - 20);
    Source_Ebenen_Kanal_wert = map((long)PWM_pulse_width[kSrc - 20], 938, 2063, 0, 100);
  }

  Source_Ebenen_Um_Kanal_wert = Source_Ebenen_Um_Kanal_wert / 33;

  struct { int low; int high; uint16_t ebene; } ranges[] = {
    {  0,   5, 0 }, {  6,  18, 1 }, { 19,  30, 2 }, { 31,  43, 3 },
    { 44,  55, 99 }, { 56,  68, 4 }, { 69,  80, 5 }, { 81,  93, 6 }, { 94, 110, 7 },
  };
  for (auto& r : ranges) {
    if (Source_Ebenen_Kanal_wert >= r.low && Source_Ebenen_Kanal_wert <= r.high) {
      ebenenkanal_Data = (r.ebene == 99) ? 99 : (Source_Ebenen_Um_Kanal_wert * 8 + r.ebene);
      break;
    }
  }
}
