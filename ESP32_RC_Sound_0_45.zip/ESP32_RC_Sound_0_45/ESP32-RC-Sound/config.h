#ifndef CONFIG_H
#define CONFIG_H

/*
 * config.h  –  ESP32-RC-Sound v0.45
 *
 * ÄNDERUNGEN v0.45:
 *   - NVS (Preferences) statt EEPROM – verschleißschonender, robuster.
 *   - configDirty-Flag: saveConfig() schreibt nur bei tatsächlicher Änderung.
 *   - config.version entfernt (NVS kennt Keys direkt, kein Migrations-Hack nötig).
 *   - Alle Felder identisch zu v0.44 – kein Breaking Change.
 */

#include <Arduino.h>

struct ConfigData {
  int Source_Start_Sound[9];
  int Volumen_Sound[9];
  int Mode_Sound[9];
  int Source_Speed_Sound_0;
  int throttle_mode;
  int Min_Speed_Sound_0;
  int Max_Speed_Sound_0;
  int Einkanal_Channel;
  int Einkanal_mode;
  int Einkanal_RC_System;
  int modul_adress;
  int Source_Ebenen_Um_Kanal;
  int Source_Ebenen_Kanal;
  int throttle_ramp;
  int throttle_dead_band;
  int shutdowndelay;
  int engine_on_toggle;
  int Hardware_Config;
  int PWM_scale_min;
  int PWM_scale_max;
  int Volumen_Source[9];
  char WiFi_SSID[32];
  char WiFi_Password[64];
};

extern ConfigData config;

// NVS-Dirty-Flag: wird von allen Schreibzugriffen gesetzt
extern bool configDirty;

void loadConfig();
void saveConfig();        // Schreibt nur wenn configDirty == true
void saveConfigForce();   // Schreibt immer (z. B. nach Reset)
void markDirty();         // Setzt configDirty = true
void Reset_all();
void set_sbus();
void set_pwm();
void set_pin();

#endif
