/*
 * config.cpp  –  ESP32-RC-Sound v0.45
 *
 * ÄNDERUNGEN v0.45:
 *   - Komplett auf NVS (Preferences) umgestellt – kein EEPROM mehr.
 *   - configDirty-Flag: spart Flash-Schreibzyklen.
 *   - saveConfig() ist idempotent: kein Schreiben ohne Änderung.
 *   - loadConfig() lädt Keys einzeln → abwärtskompatibel bei neuen Keys.
 *   - Logging verbessert.
 */

#include "config.h"
#include <Preferences.h>

ConfigData config;
bool configDirty = false;
extern uint16_t Version;

static constexpr const char* NVS_NS = "rcsound";

void markDirty() { configDirty = true; }

// ======== Hilfsmakros für NVS ====================================
#define NVS_GET_INT(p, key, field, def) field = p.getInt(key, def)
#define NVS_PUT_INT(p, key, field)      p.putInt(key, field)

// ======== Werkseinstellungen =====================================
void Reset_all() {
    for (int i = 0; i < 9; i++) {
        config.Source_Start_Sound[i] = 999;
        config.Volumen_Sound[i]      = 100;
        config.Mode_Sound[i]         = 0;
        config.Volumen_Source[i]     = 999;
    }
    config.Source_Speed_Sound_0   = 999;
    config.throttle_mode          = 0;
    config.Min_Speed_Sound_0      = 100;
    config.Max_Speed_Sound_0      = 300;
    config.Einkanal_Channel       = 999;
    config.Einkanal_mode          = 0;
    config.Einkanal_RC_System     = 0;
    config.modul_adress           = 0;
    config.Source_Ebenen_Um_Kanal = 999;
    config.Source_Ebenen_Kanal    = 999;
    config.throttle_ramp          = 20;
    config.throttle_dead_band     = 10;
    config.shutdowndelay          = 0;
    config.engine_on_toggle       = 0;
    config.Hardware_Config        = 0;
    config.PWM_scale_min          = 1000;
    config.PWM_scale_max          = 2000;
    strncpy(config.WiFi_SSID,     "ESP32-RC-Sound", sizeof(config.WiFi_SSID)     - 1);
    config.WiFi_SSID[sizeof(config.WiFi_SSID) - 1] = '\0';
    strncpy(config.WiFi_Password, "123456789",      sizeof(config.WiFi_Password) - 1);
    config.WiFi_Password[sizeof(config.WiFi_Password) - 1] = '\0';

    configDirty = true;
    Serial.println("Werkseinstellungen geladen.");
}

// ======== Voreinstellung SBUS ====================================
static void applyPreset(const int soundSrcs[9], int speedSrc) {
    for (int i = 0; i < 9; i++) config.Source_Start_Sound[i] = soundSrcs[i];
    for (int i = 0; i < 9; i++) config.Volumen_Sound[i]      = 100;
    for (int i = 0; i < 9; i++) config.Mode_Sound[i]         = 0;
    for (int i = 0; i < 9; i++) config.Volumen_Source[i]     = 999;
    config.Source_Speed_Sound_0   = speedSrc;
    config.Min_Speed_Sound_0      = 100;
    config.Max_Speed_Sound_0      = 300;
    config.shutdowndelay          = 0;
    config.engine_on_toggle       = 0;
    config.Einkanal_Channel       = 999;
    config.Source_Ebenen_Um_Kanal = 999;
    config.Source_Ebenen_Kanal    = 999;
    config.throttle_ramp          = 20;
    config.throttle_dead_band     = 10;
    config.PWM_scale_min          = 1000;
    config.PWM_scale_max          = 2000;
    configDirty = true;
}
void set_sbus() { const int s[]={10,11,12,13,14,999,999,999,999}; applyPreset(s,1); }
void set_pwm()  { const int s[]={41,42,43,44,45,999,999,999,999}; applyPreset(s,20); }
void set_pin()  { const int s[]={61,62,63,64,999,999,999,999,999}; applyPreset(s,20); }

// ======== Laden aus NVS ==========================================
void loadConfig() {
    // Zuerst Defaults setzen
    Reset_all();
    configDirty = false;  // Reset_all setzt dirty, aber wir laden ja gleich

    Preferences p;
    p.begin(NVS_NS, true);  // read-only

    if (!p.isKey("sss0")) {
        // Kein gespeicherter Config-Block → Werkseinstellungen behalten
        p.end();
        Serial.println("NVS leer – Werkseinstellungen werden verwendet.");
        configDirty = true;  // Beim nächsten save() speichern
        return;
    }

    char key[8];
    for (int i = 0; i < 9; i++) {
        snprintf(key, sizeof(key), "sss%d", i); config.Source_Start_Sound[i] = p.getInt(key, 999);
        snprintf(key, sizeof(key), "vs%d",  i); config.Volumen_Sound[i]      = p.getInt(key, 100);
        snprintf(key, sizeof(key), "ms%d",  i); config.Mode_Sound[i]         = p.getInt(key, 0);
        snprintf(key, sizeof(key), "vsrc%d",i); config.Volumen_Source[i]     = p.getInt(key, 999);
    }
    config.Source_Speed_Sound_0   = p.getInt("spd",   999);
    config.throttle_mode          = p.getInt("thrm",  0);
    config.Min_Speed_Sound_0      = p.getInt("minsp", 100);
    config.Max_Speed_Sound_0      = p.getInt("maxsp", 300);
    config.Einkanal_Channel       = p.getInt("ekch",  999);
    config.Einkanal_mode          = p.getInt("ekmo",  0);
    config.Einkanal_RC_System     = p.getInt("ekrc",  0);
    config.modul_adress           = p.getInt("madr",  0);
    config.Source_Ebenen_Um_Kanal = p.getInt("ebum",  999);
    config.Source_Ebenen_Kanal    = p.getInt("ebk",   999);
    config.throttle_ramp          = p.getInt("thrr",  20);
    config.throttle_dead_band     = p.getInt("thrdb", 10);
    config.shutdowndelay          = p.getInt("shdly", 0);
    config.engine_on_toggle       = p.getInt("entog", 0);
    config.Hardware_Config        = p.getInt("hwcfg", 0);
    config.PWM_scale_min          = p.getInt("pwmin", 1000);
    config.PWM_scale_max          = p.getInt("pwmax", 2000);

    String ssid = p.getString("ssid", "ESP32-RC-Sound");
    String pass = p.getString("pass", "123456789");
    strncpy(config.WiFi_SSID,     ssid.c_str(), sizeof(config.WiFi_SSID)     - 1);
    strncpy(config.WiFi_Password, pass.c_str(), sizeof(config.WiFi_Password) - 1);
    config.WiFi_SSID[sizeof(config.WiFi_SSID)-1] = '\0';
    config.WiFi_Password[sizeof(config.WiFi_Password)-1] = '\0';

    p.end();
    configDirty = false;
    Serial.println("Config aus NVS geladen.");
}

// ======== Speichern in NVS (nur bei Änderung) ====================
void saveConfig() {
    if (!configDirty) return;
    saveConfigForce();
}

void saveConfigForce() {
    Preferences p;
    p.begin(NVS_NS, false);  // read-write

    char key[8];
    for (int i = 0; i < 9; i++) {
        snprintf(key, sizeof(key), "sss%d", i); p.putInt(key, config.Source_Start_Sound[i]);
        snprintf(key, sizeof(key), "vs%d",  i); p.putInt(key, config.Volumen_Sound[i]);
        snprintf(key, sizeof(key), "ms%d",  i); p.putInt(key, config.Mode_Sound[i]);
        snprintf(key, sizeof(key), "vsrc%d",i); p.putInt(key, config.Volumen_Source[i]);
    }
    p.putInt("spd",   config.Source_Speed_Sound_0);
    p.putInt("thrm",  config.throttle_mode);
    p.putInt("minsp", config.Min_Speed_Sound_0);
    p.putInt("maxsp", config.Max_Speed_Sound_0);
    p.putInt("ekch",  config.Einkanal_Channel);
    p.putInt("ekmo",  config.Einkanal_mode);
    p.putInt("ekrc",  config.Einkanal_RC_System);
    p.putInt("madr",  config.modul_adress);
    p.putInt("ebum",  config.Source_Ebenen_Um_Kanal);
    p.putInt("ebk",   config.Source_Ebenen_Kanal);
    p.putInt("thrr",  config.throttle_ramp);
    p.putInt("thrdb", config.throttle_dead_band);
    p.putInt("shdly", config.shutdowndelay);
    p.putInt("entog", config.engine_on_toggle);
    p.putInt("hwcfg", config.Hardware_Config);
    p.putInt("pwmin", config.PWM_scale_min);
    p.putInt("pwmax", config.PWM_scale_max);
    p.putString("ssid", config.WiFi_SSID);
    p.putString("pass", config.WiFi_Password);

    p.end();
    configDirty = false;
    Serial.println("Config in NVS gespeichert.");
}
